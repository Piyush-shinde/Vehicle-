package com.Utils;

import java.sql.Connection;
import java.sql.DriverManager;

public class DbConnection {
	public static Connection getConnect(){
		
		Connection conn = null;
		
		try{
			Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
			conn = DriverManager.getConnection("jdbc:derby:D:\\\\Users\\\\2792972\\\\NewDb;create=true");
			System.out.println("Connected");
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return conn;
	}
}
